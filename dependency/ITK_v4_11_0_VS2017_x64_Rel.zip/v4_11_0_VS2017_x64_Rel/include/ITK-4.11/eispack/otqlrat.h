extern int v3p_netlib_tqlrat_(
  v3p_netlib_integer *n,
  v3p_netlib_doublereal *d__,
  v3p_netlib_doublereal *e2,
  v3p_netlib_integer *ierr
  );
