extern int v3p_netlib_zswap_(
  v3p_netlib_integer *n,
  v3p_netlib_doublecomplex *zx,
  v3p_netlib_integer *incx,
  v3p_netlib_doublecomplex *zy,
  v3p_netlib_integer *incy
  );
