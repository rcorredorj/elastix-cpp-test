extern int v3p_netlib_sgemv_(
  char *trans,
  v3p_netlib_integer *m,
  v3p_netlib_integer *n,
  v3p_netlib_real *alpha,
  v3p_netlib_real *a,
  v3p_netlib_integer *lda,
  v3p_netlib_real *x,
  v3p_netlib_integer *incx,
  v3p_netlib_real *beta,
  v3p_netlib_real *y,
  v3p_netlib_integer *incy,
  v3p_netlib_ftnlen trans_len
  );
